const factorySteps = [
  ["Research", "Finds fresh trucking topics and industry pain points."],
  ["Script", "Writes a new hook, voiceover, CTA, and captions."],
  ["Visuals", "Matches stock road, yard, cab, freight, and compliance scenes."],
  ["Voice", "Packages the script with the selected AI narrator."],
  ["Captions", "Adds subtitle-first text for Reels, Shorts, and Facebook."],
  ["Publish", "Queues metadata and scheduled posts after approval."]
];

const ideas = [
  {
    title: "Why paperwork discipline wins more loads",
    caption: "Clean paperwork keeps freight moving.",
    summary: "A practical trucking short that shows how clean documents, fast communication, and RUNVARA support keep freight moving.",
    tags: ["trucking", "freight", "fleetmanagement", "runvara"],
    script:
      "Hook: The fastest truck can still lose time when the paperwork is messy.\n\nVoiceover: Before a load moves, documents need to be clean, easy to find, and ready for whoever needs them next. That discipline protects the driver, the dispatcher, and the customer relationship.\n\nRUNVARA angle: RUNVARA helps trucking teams look organized, professional, and ready for the next load.\n\nCTA: Follow RUNVARA for daily trucking growth systems."
  },
  {
    title: "The owner-operator math nobody should ignore",
    caption: "Busy miles are not always profitable miles.",
    summary: "A short-form breakdown of deadhead, communication, and rate discipline for small trucking businesses.",
    tags: ["owneroperator", "truckingbusiness", "freightrates", "runvara"],
    script:
      "Hook: More miles do not always mean more money.\n\nVoiceover: A profitable week comes from the right miles, clean planning, and fewer surprises. Watch deadhead, protect your time, and know what each load really costs before you say yes.\n\nRUNVARA angle: RUNVARA turns practical trucking knowledge into content that builds trust.\n\nCTA: Save this before you book the next load."
  },
  {
    title: "Three safety habits that make a fleet look professional",
    caption: "Safety content builds trust before the sales call.",
    summary: "A brand-safe trucking safety video built for fleets, drivers, and carrier pages.",
    tags: ["fleetsafety", "cdldrivers", "carrier", "runvara"],
    script:
      "Hook: Safety is not just a checklist. It is part of your brand.\n\nVoiceover: Start with pre-trip discipline, clear driver communication, and simple documentation habits. Those details show shippers, brokers, and drivers that your operation takes the work seriously.\n\nRUNVARA angle: RUNVARA helps trucking brands turn daily discipline into visible authority.\n\nCTA: Follow RUNVARA for more trucking content ideas."
  }
];

const calendarTopics = [
  "Inspection prep that saves roadside time",
  "How dispatchers build trust with drivers",
  "The real cost of messy documents",
  "What shippers notice about professional carriers",
  "How to turn safety habits into content",
  "Owner-operator rate discipline in plain English",
  "Why driver retention starts with communication",
  "How RUNVARA helps trucking brands stay visible",
  "The difference between busy and profitable",
  "What to post when freight feels slow"
];

let selectedIdea = 0;
let activeStep = 0;
let filter = "all";
let calendar = createCalendar();
let connectionStatus = null;

function createCalendar() {
  const today = new Date();
  return Array.from({ length: 30 }, (_, index) => {
    const date = new Date(today);
    date.setDate(today.getDate() + index);
    return {
      id: index + 1,
      date,
      topic: calendarTopics[index % calendarTopics.length],
      format: index % 3 === 0 ? "YouTube Short + Reels" : index % 3 === 1 ? "Facebook native video" : "Multi-platform package",
      status: index < 3 ? "queued" : "draft"
    };
  });
}

function renderFactory() {
  const container = document.querySelector("#factory-steps");
  container.innerHTML = factorySteps.map(([title, description], index) => `
    <article class="factory-step ${index === activeStep ? "is-active" : ""}">
      <b>${String(index + 1).padStart(2, "0")}</b>
      <strong>${title}</strong>
      <span>${description}</span>
    </article>
  `).join("");
}

function renderIdea() {
  const idea = ideas[selectedIdea];
  document.querySelector("#generated-title").textContent = idea.title;
  document.querySelector("#generated-summary").textContent = idea.summary;
  document.querySelector("#script-editor").value = idea.script;
  document.querySelector("#caption-strip").textContent = idea.caption;
  renderCreatedPosts();
  document.querySelector("#review-state").textContent = "Needs review";
  document.querySelector("#review-state").className = "status-pill pending";
  setChannelStates("Draft");
}

function buildContentPackage() {
  const idea = ideas[selectedIdea];
  const script = document.querySelector("#script-editor")?.value || idea.script;
  const hashtags = idea.tags.map((tag) => `#${tag}`).join(" ");
  return {
    videoAsset: `RUNVARA vertical short | 58 seconds | 9:16 | Topic: ${idea.title} | Includes stock road footage, AI voiceover, burned-in captions, lower-third RUNVARA branding, and end-card CTA.`,
    youtube: `${idea.title}\n\n${idea.summary}\n\nScript:\n${script}\n\nTags: ${idea.tags.join(", ")}\nCTA: Follow RUNVARA for daily trucking growth systems.`,
    facebook: `${idea.caption}\n\n${idea.summary}\n\nRUNVARA helps trucking teams turn daily discipline into a stronger brand. What is one habit your fleet never skips?\n\n${hashtags}`,
    instagram: `${idea.caption}\n\n${idea.summary}\n\nSave this for your next trucking content idea.\n\n${hashtags} #trucktok #logistics #freightlife`,
    script
  };
}

function renderCreatedPosts() {
  const content = buildContentPackage();
  document.querySelector("#video-asset").textContent = content.videoAsset;
  document.querySelector("#youtube-post").value = content.youtube;
  document.querySelector("#facebook-post").value = content.facebook;
  document.querySelector("#instagram-post").value = content.instagram;
}

function renderCalendar() {
  const list = document.querySelector("#calendar-list");
  const visible = filter === "all" ? calendar : calendar.filter((item) => item.status === filter);
  list.innerHTML = visible.map((item) => `
    <article class="calendar-item">
      <div class="calendar-top">
        <span class="calendar-date">${item.date.toLocaleString("en-US", { month: "short", day: "numeric" })}</span>
        <span class="calendar-status ${item.status}">${item.status}</span>
      </div>
      <h3>${item.topic}</h3>
      <p>${item.format}</p>
    </article>
  `).join("");
}

function setChannelStates(state) {
  ["youtube", "facebook", "instagram"].forEach((channel) => {
    document.querySelector(`#${channel}-state`).textContent = state;
  });
}

async function loadConnectionStatus() {
  try {
    const response = await fetch("/api/status");
    connectionStatus = await response.json();
    const metaText = connectionStatus.meta.configured
      ? connectionStatus.meta.hasToken
        ? "Configured with token"
        : "App configured, token needed"
      : "Needs Meta app credentials";
    const youtubeText = connectionStatus.youtube.configured
      ? connectionStatus.youtube.hasToken
        ? "Configured with token"
        : "App configured, token needed"
      : "Needs Google OAuth credentials";
    document.querySelector("#meta-connection").textContent = metaText;
    document.querySelector("#youtube-connection").textContent = youtubeText;
  } catch (error) {
    document.querySelector("#meta-connection").textContent = "Status unavailable";
    document.querySelector("#youtube-connection").textContent = "Status unavailable";
  }
}

function showToast(message) {
  const toast = document.querySelector("#toast");
  toast.textContent = message;
  toast.classList.add("is-visible");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("is-visible"), 2600);
}

function bindEvents() {
  document.querySelector("#build-video").addEventListener("click", () => {
    selectedIdea = (selectedIdea + 1) % ideas.length;
    activeStep = 5;
    renderIdea();
    renderFactory();
    showToast("Fresh trucking video package generated.");
  });

  document.querySelector("#simulate-progress").addEventListener("click", () => {
    activeStep = (activeStep + 1) % factorySteps.length;
    renderFactory();
    showToast(`${factorySteps[activeStep][0]} stage is active.`);
  });

  document.querySelector("#refresh-plan").addEventListener("click", () => {
    calendar = createCalendar().map((item, index) => ({
      ...item,
      topic: calendarTopics[(index + selectedIdea + 2) % calendarTopics.length]
    }));
    renderCalendar();
    showToast("New 30-day trucking video plan created.");
  });

  document.querySelector("#regenerate").addEventListener("click", () => {
    selectedIdea = (selectedIdea + 1) % ideas.length;
    renderIdea();
    showToast("Script, title, and captions regenerated.");
  });

  document.querySelector("#save-script").addEventListener("click", () => {
    ideas[selectedIdea].script = document.querySelector("#script-editor").value;
    renderCreatedPosts();
    showToast("Script edits saved.");
  });

  document.querySelector("#approve-video").addEventListener("click", () => {
    document.querySelector("#review-state").textContent = "Queued";
    document.querySelector("#review-state").className = "status-pill ready";
    renderCreatedPosts();
    setChannelStates("Queued");
    showToast("Video and posts created, approved, and queued.");
  });

  document.querySelector("#download-package").addEventListener("click", () => {
    renderCreatedPosts();
    const idea = ideas[selectedIdea];
    const content = buildContentPackage();
    const body = [
      `RUNVARA CONTENT PACKAGE`,
      `Title: ${idea.title}`,
      ``,
      `VIDEO ASSET`,
      content.videoAsset,
      ``,
      `SCRIPT`,
      content.script,
      ``,
      `YOUTUBE POST`,
      content.youtube,
      ``,
      `FACEBOOK POST`,
      content.facebook,
      ``,
      `INSTAGRAM POST`,
      content.instagram
    ].join("\n");
    const blob = new Blob([body], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `runvara-content-package-${Date.now()}.txt`;
    link.click();
    URL.revokeObjectURL(url);
    showToast("Content package downloaded.");
  });

  document.querySelectorAll(".publish-button").forEach((button) => {
    button.addEventListener("click", async () => {
      renderCreatedPosts();
      const platform = button.dataset.platform;
      const content = buildContentPackage();
      button.disabled = true;
      try {
        const response = await fetch("/api/publish", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            platform,
            title: ideas[selectedIdea].title,
            videoAsset: content.videoAsset,
            youtubePost: content.youtube,
            facebookPost: content.facebook,
            instagramPost: content.instagram
          })
        });
        const result = await response.json();
        document.querySelector(`#${platform}-state`).textContent = result.mode === "dry_run" ? "Dry run" : response.ok ? "Sent" : "Needs setup";
        showToast(result.message || result.error || `${platform} publish request sent.`);
      } catch (error) {
        document.querySelector(`#${platform}-state`).textContent = "Error";
        showToast("Publish request failed.");
      } finally {
        button.disabled = false;
      }
    });
  });

  document.querySelectorAll(".segmented button").forEach((button) => {
    button.addEventListener("click", () => {
      document.querySelectorAll(".segmented button").forEach((control) => control.classList.remove("is-selected"));
      button.classList.add("is-selected");
      filter = button.dataset.filter;
      renderCalendar();
    });
  });

  ["#niche-select", "#format-select", "#voice-select"].forEach((selector) => {
    document.querySelector(selector).addEventListener("change", () => {
      renderCreatedPosts();
      showToast("Video brief updated for the next generation.");
    });
  });
}

renderFactory();
renderIdea();
renderCalendar();
bindEvents();
loadConnectionStatus();
