# RUNVARA Content Command

RUNVARA Content Command is a trucking-industry content operations app for planning, reviewing, and queuing content across YouTube, Facebook, and Instagram.

## What It Includes

- 14 AI-style content agents
- Instant 30-day trucking content calendar
- Script regeneration and manual script editing
- Approval workflow before publishing
- YouTube compliance checklist
- Platform queues for YouTube, Facebook, and Instagram
- RUNVARA brand placement throughout the content workflow

## Run Locally

```bash
npm start
```

Then open `http://localhost:4173`.

## Deploy To Railway

1. Push this repository to GitHub.
2. In Railway, choose **New Project**.
3. Select **Deploy from GitHub repo**.
4. Choose this repository.
5. Railway will use `npm start` from `railway.json`.

## Social Account Setup

The app includes backend routes for connecting Meta and YouTube:

- `/connect/meta`
- `/connect/youtube`
- `/api/status`
- `/api/publish`
- `/webhooks/meta`

Add the variables from `.env.example` in Railway. Keep `PUBLISHING_ENABLED=false` until your Meta and Google apps, permissions, tokens, and public video URLs are ready.

Facebook and Instagram publishing require a Meta Developer App, a Facebook Page, and a Professional Instagram account linked to that Page. YouTube publishing requires a Google Cloud OAuth client and YouTube Data API access.

## Meta Webhook Setup

Use this callback URL in Meta:

```text
https://your-railway-domain.up.railway.app/webhooks/meta
```

Use this verify token, or set your own matching value in Railway:

```text
RUNVARA_META_VERIFY_2026
```
