const http = require("http");
const fs = require("fs");
const path = require("path");

const distDir = path.join(__dirname, "dist");
const publicDir = fs.existsSync(path.join(distDir, "index.html")) ? distDir : __dirname;
const port = Number(process.env.PORT) || 4173;

const contentTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".txt": "text/plain; charset=utf-8"
};

const metaScopes = [
  "pages_show_list",
  "pages_read_engagement",
  "pages_manage_posts",
  "instagram_basic",
  "instagram_content_publish"
];
const youtubeScopes = ["https://www.googleapis.com/auth/youtube.upload"];

function appBaseUrl(req) {
  if (process.env.PUBLIC_BASE_URL) return process.env.PUBLIC_BASE_URL.replace(/\/$/, "");
  const host = req.headers.host || `localhost:${port}`;
  const proto = host.includes("localhost") ? "http" : "https";
  return `${proto}://${host}`;
}

function json(res, status, payload) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload, null, 2));
}

function html(res, status, title, body) {
  res.writeHead(status, { "Content-Type": "text/html; charset=utf-8" });
  res.end(`<!doctype html><html><head><title>${title}</title><style>body{font-family:system-ui;margin:40px;line-height:1.5;max-width:760px}code{background:#f1f3f5;padding:2px 5px;border-radius:4px}</style></head><body>${body}</body></html>`);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) {
        req.destroy();
        reject(new Error("Request body too large"));
      }
    });
    req.on("end", () => resolve(body ? JSON.parse(body) : {}));
    req.on("error", reject);
  });
}

function connectionStatus(req) {
  return {
    baseUrl: appBaseUrl(req),
    meta: {
      configured: Boolean(process.env.META_APP_ID && process.env.META_APP_SECRET),
      pageReady: Boolean(process.env.META_PAGE_ID),
      instagramReady: Boolean(process.env.INSTAGRAM_USER_ID),
      hasToken: Boolean(process.env.META_PAGE_ACCESS_TOKEN)
    },
    youtube: {
      configured: Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
      hasToken: Boolean(process.env.YOUTUBE_ACCESS_TOKEN || process.env.YOUTUBE_REFRESH_TOKEN)
    },
    publishingEnabled: process.env.PUBLISHING_ENABLED === "true"
  };
}

function handleMetaConnect(req, res) {
  if (!process.env.META_APP_ID) {
    json(res, 400, {
      error: "Meta is not configured yet.",
      needed: ["META_APP_ID", "META_APP_SECRET", "PUBLIC_BASE_URL"]
    });
    return;
  }

  const redirectUri = process.env.META_REDIRECT_URI || `${appBaseUrl(req)}/oauth/meta/callback`;
  const url = new URL("https://www.facebook.com/v20.0/dialog/oauth");
  url.searchParams.set("client_id", process.env.META_APP_ID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("scope", metaScopes.join(","));
  url.searchParams.set("response_type", "code");
  url.searchParams.set("state", "runvara-meta");
  res.writeHead(302, { Location: url.toString() });
  res.end();
}

function handleYouTubeConnect(req, res) {
  if (!process.env.GOOGLE_CLIENT_ID) {
    json(res, 400, {
      error: "YouTube is not configured yet.",
      needed: ["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET", "PUBLIC_BASE_URL"]
    });
    return;
  }

  const redirectUri = process.env.GOOGLE_REDIRECT_URI || `${appBaseUrl(req)}/oauth/youtube/callback`;
  const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  url.searchParams.set("client_id", process.env.GOOGLE_CLIENT_ID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", youtubeScopes.join(" "));
  url.searchParams.set("access_type", "offline");
  url.searchParams.set("prompt", "consent");
  url.searchParams.set("state", "runvara-youtube");
  res.writeHead(302, { Location: url.toString() });
  res.end();
}

function handleOAuthCallback(req, res, platform) {
  const url = new URL(req.url, `http://localhost:${port}`);
  const code = url.searchParams.get("code");
  if (!code) {
    html(res, 400, "Connection failed", `<h1>${platform} connection failed</h1><p>No authorization code was returned.</p>`);
    return;
  }

  html(
    res,
    200,
    `${platform} connected`,
    `<h1>${platform} authorization received</h1><p>The app received an authorization code. The next production step is exchanging this code server-side for long-lived tokens and saving them as encrypted secrets.</p><p>You can close this tab and return to RUNVARA Clips Engine.</p>`
  );
}

function handleMetaWebhookVerify(req, res) {
  const url = new URL(req.url, `http://localhost:${port}`);
  const mode = url.searchParams.get("hub.mode");
  const token = url.searchParams.get("hub.verify_token");
  const challenge = url.searchParams.get("hub.challenge");
  const expectedToken = process.env.META_WEBHOOK_VERIFY_TOKEN || "RUNVARA_META_VERIFY_2026";

  if (mode === "subscribe" && token === expectedToken && challenge) {
    res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
    res.end(challenge);
    return;
  }

  json(res, 403, {
    error: "Webhook verification failed.",
    expected: "hub.mode=subscribe with the correct verify token."
  });
}

async function handleMetaWebhookEvent(req, res) {
  const body = await readBody(req);
  console.log("Meta webhook event received:", JSON.stringify(body));
  json(res, 200, { received: true });
}

async function handlePublish(req, res) {
  const status = connectionStatus(req);
  const body = await readBody(req);
  const platform = body.platform;

  if (!["youtube", "facebook", "instagram"].includes(platform)) {
    json(res, 400, { error: "Unknown platform." });
    return;
  }

  if (process.env.PUBLISHING_ENABLED !== "true") {
    json(res, 202, {
      mode: "dry_run",
      message: "Publishing is wired but disabled. Add credentials/tokens in Railway and set PUBLISHING_ENABLED=true.",
      received: body
    });
    return;
  }

  if (platform === "youtube" && !(status.youtube.hasToken && body.videoUrl)) {
    json(res, 400, {
      error: "YouTube publishing needs YOUTUBE_ACCESS_TOKEN or YOUTUBE_REFRESH_TOKEN and a public videoUrl for the MP4."
    });
    return;
  }

  if (platform === "facebook" && !(status.meta.hasToken && status.meta.pageReady)) {
    json(res, 400, {
      error: "Facebook publishing needs META_PAGE_ACCESS_TOKEN and META_PAGE_ID."
    });
    return;
  }

  if (platform === "instagram" && !(status.meta.hasToken && status.meta.instagramReady && body.videoUrl)) {
    json(res, 400, {
      error: "Instagram publishing needs META_PAGE_ACCESS_TOKEN, INSTAGRAM_USER_ID, and a public videoUrl for the Reel."
    });
    return;
  }

  json(res, 501, {
    error: "Live API publishing is ready to implement after tokens and public video hosting are configured.",
    next: "Connect an object store or video renderer that creates a public MP4 URL, then call the official platform upload endpoints."
  });
}

function resolveFile(requestUrl) {
  const parsedUrl = new URL(requestUrl, `http://localhost:${port}`);
  const cleanPath = decodeURIComponent(parsedUrl.pathname);
  const requested = cleanPath === "/" ? "/index.html" : cleanPath;
  const filePath = path.normalize(path.join(publicDir, requested));
  if (!filePath.startsWith(publicDir)) return null;
  return filePath;
}

function serveStatic(req, res) {
  const filePath = resolveFile(req.url || "/");
  if (!filePath) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  fs.readFile(filePath, (error, data) => {
    if (error) {
      fs.readFile(path.join(publicDir, "index.html"), (fallbackError, fallbackData) => {
        if (fallbackError) {
          res.writeHead(404);
          res.end("Not found");
          return;
        }
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(fallbackData);
      });
      return;
    }

    res.writeHead(200, {
      "Content-Type": contentTypes[path.extname(filePath)] || "application/octet-stream",
      "Cache-Control": "no-store"
    });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || "/", `http://localhost:${port}`);

    if (req.method === "GET" && url.pathname === "/api/status") {
      json(res, 200, connectionStatus(req));
      return;
    }

    if (req.method === "GET" && url.pathname === "/connect/meta") {
      handleMetaConnect(req, res);
      return;
    }

    if (req.method === "GET" && url.pathname === "/connect/youtube") {
      handleYouTubeConnect(req, res);
      return;
    }

    if (req.method === "GET" && url.pathname === "/oauth/meta/callback") {
      handleOAuthCallback(req, res, "Meta");
      return;
    }

    if (req.method === "GET" && url.pathname === "/oauth/youtube/callback") {
      handleOAuthCallback(req, res, "YouTube");
      return;
    }

    if (req.method === "GET" && url.pathname === "/webhooks/meta") {
      handleMetaWebhookVerify(req, res);
      return;
    }

    if (req.method === "POST" && url.pathname === "/webhooks/meta") {
      await handleMetaWebhookEvent(req, res);
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/publish") {
      await handlePublish(req, res);
      return;
    }

    serveStatic(req, res);
  } catch (error) {
    json(res, 500, { error: error.message || "Server error" });
  }
});

server.listen(port, () => {
  console.log(`RUNVARA Clips Engine running on port ${port}`);
});
